SET DEFINE OFF;
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (1, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (1, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (1, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (1, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (1, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (1, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (1, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (1, 8, 'Asignatura 8');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (1, 9, 'Asignatura 9');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (2, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (2, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (2, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (2, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (2, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (2, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (2, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (3, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (3, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (3, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (3, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (3, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (3, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (3, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (3, 8, 'Asignatura 8');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (3, 9, 'Asignatura 9');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (4, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (4, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (4, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (4, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (4, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (4, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (5, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (5, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (5, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (5, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (5, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (5, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (6, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (6, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (6, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (6, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (6, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (6, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (6, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (6, 8, 'Asignatura 8');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (6, 9, 'Asignatura 9');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (7, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (7, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (7, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (7, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (7, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (7, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (7, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (8, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (8, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (8, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (8, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (8, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (8, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (9, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (9, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (9, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (9, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (9, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (9, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (9, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (10, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (10, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (10, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (10, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (10, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (10, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (11, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (11, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (11, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (11, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (11, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (11, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (12, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (12, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (12, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (12, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (12, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (12, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (13, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (13, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (13, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (13, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (13, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (13, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (14, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (14, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (14, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (14, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (14, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (14, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (14, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (14, 8, 'Asignatura 8');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (15, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (15, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (15, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (15, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (15, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (15, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (15, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (15, 8, 'Asignatura 8');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (15, 9, 'Asignatura 9');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (16, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (16, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (16, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (16, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (16, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (16, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (16, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (16, 8, 'Asignatura 8');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (16, 9, 'Asignatura 9');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (17, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (17, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (17, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (17, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (17, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (17, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (18, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (18, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (18, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (18, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (18, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (18, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (18, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (18, 8, 'Asignatura 8');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (19, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (19, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (19, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (19, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (19, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (19, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (19, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (19, 8, 'Asignatura 8');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (19, 9, 'Asignatura 9');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (20, 1, 'Asignatura 1');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (20, 2, 'Asignatura 2');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (20, 3, 'Asignatura 3');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (20, 4, 'Asignatura 4');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (20, 5, 'Asignatura 5');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (20, 6, 'Asignatura 6');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (20, 7, 'Asignatura 7');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (20, 8, 'Asignatura 8');
Insert into CURSO_ASIGNATURA
   (ID_CURSO, ID_ASIGNATURA, NOMBRE)
 Values
   (20, 9, 'Asignatura 9');
COMMIT;
