import java.util.*;

public class Alumno
{
	
	private String nif;
	
	private String nombre;
	
	private String apellido1;
	
	private String apellido2;
	
	private Date fechaNacimiento;
	
	private String localidad;
	
	private String telefono;

	private String email;

	
	public Alumno(String nif, String nombre, String apellido1, String apellido2, Date fechaNacimiento, String localidad, String telefono, String email) 
	{
		this.nif = nif;
		this.nombre = nombre;
		this.apellido1 = apellido1;
		this.apellido2 = apellido2;
		this.fechaNacimiento = fechaNacimiento;
		this.localidad = localidad;
		this.telefono = telefono;
		this.email = email;
	}
	
	public String getNif() {
		return nif;
	}
	
	public String getNombre() {
		return nombre;
	}

	public String getApellido1() {
		return apellido1;
	}	
	
	public String getApellido2() {
		return apellido2;
	}
	
	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}	
	
	public String getLocalidad() {
		return localidad;
	}
	
	public String getTelefono() {
		return telefono;
	}

	public String getEmail() {
		return email;
	}
	
}