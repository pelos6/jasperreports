import java.util.*;
import java.text.*;

public class AlumnoFactory
{

	public static Alumno[] crearAlumnos ()
	{
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		
		Alumno[] listaAlumnos = new Alumno[3];
	
		try
		{
			listaAlumnos[0] = new Alumno("11111111A", "Nombre 1", "Apellido1 1", "Apellido2 1", dateFormat.parse("01/01/1980"), "Localidad 1", "111111111", "111@aragon.es");
			listaAlumnos[1] = new Alumno("22222222B", "Nombre 2", "Apellido1 2", "Apellido2 2", dateFormat.parse("01/01/1957"), "Localidad 2", "222222222", "222@aragon.es");
			listaAlumnos[2] = new Alumno("33333333C", "Nombre 3", "Apellido1 3", "Apellido2 2", dateFormat.parse("01/01/1991"), "Localidad 3", "333333333", "333@aragon.es");
		}
		catch (Exception ex)
		{
			
		};
		
		return listaAlumnos;
		
	}

}