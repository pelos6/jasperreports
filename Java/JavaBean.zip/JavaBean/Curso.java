import java.util.*;

public class Curso
{
	
	private int idCurso;
	
	private String nombre;
	
	private int numHoras;
	
	private Date fechaInicio;
	
	private Date fechaFin;
	
	
	
	public Curso(int idCurso, String nombre, int numHoras, Date fechaInicio, Date fechaFin) 
	{
		this.idCurso = idCurso;
		this.nombre = nombre;
		this.numHoras = numHoras;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
	}
	
	public int getIdCurso() {
		return idCurso;
	}
	
	public String getNombre() {
		return nombre;
	}

	public int getNumHoras() {
		return numHoras;
	}	
	
	public Date getFechaInicio() {
		return fechaInicio;
	}
	
	public Date getFechaFin() {
		return fechaFin;
	}	
	
}