import java.util.*;
import java.text.*;

public class CursoFactory
{

	public static Curso[] crearCursos ()
	{
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		
		Curso[] listaCursos = new Curso[3];
	
		try
		{
			listaCursos[0] = new Curso(1, "Curso 1", 100, dateFormat.parse("01/01/2016"), dateFormat.parse("01/01/2017"));
			listaCursos[1] = new Curso(2, "Curso 2", 200, dateFormat.parse("01/05/2017"), dateFormat.parse("21/01/2018"));
			listaCursos[2] = new Curso(3, "Curso 3", 300, dateFormat.parse("01/03/2016"), dateFormat.parse("01/10/2017"));
		}
		catch (Exception ex)
		{
			
		};
		
		return listaCursos;
		
	}

}